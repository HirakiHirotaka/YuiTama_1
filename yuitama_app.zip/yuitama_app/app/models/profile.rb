class Profile < ApplicationRecord
  belongs_to :utinaantyu
end
