class PersonalInfoController < ApplicationController
  def input
  end
  def regiComp
  end
  def mypage
  end
  def editProf
  end
end
