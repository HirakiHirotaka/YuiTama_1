class AcceptPlanController < ApplicationController
  def planMylist
  end

  def planDetail
  end

  def planList
  end
end
