class ProvidePlanController < ApplicationController
  def planInput
	redirect_to "/plans/new"
  end

  def regiComp
  end

  def myPlanList
  end
end
