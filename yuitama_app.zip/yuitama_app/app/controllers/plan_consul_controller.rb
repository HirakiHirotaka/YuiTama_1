class PlanConsulController < ApplicationController
  def consensus
  end
end
