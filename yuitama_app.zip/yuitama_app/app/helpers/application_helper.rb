module ApplicationHelper
  include HtmlBuilder
end
