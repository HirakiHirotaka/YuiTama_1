module PlanConsulHelper
end
