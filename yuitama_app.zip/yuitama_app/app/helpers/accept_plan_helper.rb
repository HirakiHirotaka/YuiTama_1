module AcceptPlanHelper
end
