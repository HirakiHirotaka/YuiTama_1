require "application_system_test_case"

class PlansTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit plans_url
  #
  #   assert_selector "h1", text: "Plan"
  # end
end
