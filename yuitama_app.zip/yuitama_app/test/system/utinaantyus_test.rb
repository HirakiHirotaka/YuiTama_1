require "application_system_test_case"

class UtinaantyusTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit utinaantyus_url
  #
  #   assert_selector "h1", text: "Utinaantyu"
  # end
end
